import os
import argparse
import json
import shutil
from utils import ensure_dirs


def get_config(phase):
    config = Config(phase)
    return config


class Config(object):
    """Base class of Config, provide necessary hyperparameters. 
    """
    def __init__(self, phase):
        self.is_train = phase == "train"

        # init hyperparameters and parse from command-line
        parser, args = self.parse()

        # set as attributes
        print("----Experiment Configuration-----")
        for k, v in args.__dict__.items():
            print("{0:20}".format(k), v)
            self.__setattr__(k, v)

        if self.is_train:
            # experiment paths
            self.exp_dir = os.path.join(self.proj_dir, self.exp_name)
            if phase == "train" and args.cont is not True and os.path.exists(self.exp_dir):
                response = input('Experiment log/model already exists, overwrite? (y/n) ')
                if response != 'y':
                    exit()
                shutil.rmtree(self.exp_dir)

            self.log_dir = os.path.join(self.exp_dir, 'log')
            self.model_dir = os.path.join(self.exp_dir, 'model')
            ensure_dirs([self.log_dir, self.model_dir])

            # GPU usage
            if args.gpu_ids is not None:
                os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu_ids)

            # create soft link to experiment log directory
            if not os.path.exists('train_log'):
                os.symlink(self.exp_dir, 'train_log')

            # save this configuration
            if self.is_train:
                with open(os.path.join(self.exp_dir, 'config.json'), 'w') as f:
                    json.dump(args.__dict__, f, indent=2)
                copy_code_dir = os.path.join(self.exp_dir, "code")
                ensure_dirs(copy_code_dir)
                os.system("cp *.py {}".format(copy_code_dir))

    def parse(self):
        """initiaize argument parser. Define default hyperparameters and collect from command-line arguments."""
        parser = argparse.ArgumentParser()
        
        # basic configuration
        self._add_basic_config_(parser)

        # dataset configuration
        self._add_dataset_config_(parser)

        # model configuration
        self._add_network_config_(parser)

        # training or testing configuration
        self._add_training_config_(parser)

        # additional parameters if needed
        self._add_meshing_config_(parser)

        args = parser.parse_args()
        return parser, args

    def _add_basic_config_(self, parser):
        """add general hyperparameters"""
        group = parser.add_argument_group('basic')
        group.add_argument('--proj_dir', type=str, default="/home/honglinchen/projects/neural-implicit", help="path to project folder where models and logs will be saved")
        group.add_argument('--data_path', type=str, default="your-data-path", help="path to point cloud data (must in .xyz format)")
        group.add_argument('--mesh_path', type=str, default="your-data-path", help="path to point cloud data (must in .xyz format)")
        group.add_argument('--exp_name', type=str, default=os.getcwd().split('/')[-1], help="name of this experiment")
        group.add_argument('-g', '--gpu_ids', type=str, default=None, help="gpu to use, e.g. 0  0,1,2. CPU not supported.")

    def _add_dataset_config_(self, parser):
        """add hyperparameters for dataset configuration"""
        group = parser.add_argument_group('dataset')
        group.add_argument('--dataset_type', type=str, default="pointcloud", help="dataset type")
        group.add_argument('--batch_size', type=int, default=64, help="batch size")
        group.add_argument('--num_workers', type=int, default=8, help="number of workers for data loading")
        group.add_argument('--on_surface_points', type=int, default=10000, help="number of points on surface")

    def _add_network_config_(self, parser):
        """add hyperparameters for network architecture"""
        group = parser.add_argument_group('network')

        # Architecture for network
        group.add_argument('--net', type=str, default='MlpSDF', 
                            help='The network architecture to be used (MlpSDF or LodSDF).')
        group.add_argument('--activation', type=str, default='relu', 
                            help="Activation function in use (relu or sin)")
        group.add_argument('--feature-dim', type=int, default=32,
                            help='Feature map dimension')
        group.add_argument('--feature-size', type=int, default=4,
                            help='Feature map size (w/h)')
        group.add_argument('--num-layers', type=int, default=1,
                            help='Number of layers for the decoder')
        group.add_argument('--num-lods', type=int, default=1,
                            help='Number of LODs')
        group.add_argument('--base-lod', type=int, default=2,
                            help='Base level LOD')
        group.add_argument('--hidden-dim', type=int, default=128,
                            help='Network width')
        group.add_argument('--pretrained', type=str,
                            help='Path to pretrained model weights.')
        group.add_argument('--num-samples', type=int, default=100000,
                            help='Number of samples per mode (or per epoch for SPC)')
        group.add_argument('--samples-per-voxel', type=int, default=256,
                                help='Number of samples per voxel (for SPC)')
        group.add_argument('--sample-mode', type=str, nargs='*', 
                                default=['rand', 'rand', 'near', 'near', 'trace'],
                                help='The sampling scheme to be used.')


    def _add_training_config_(self, parser):
        """training configuration"""
        group = parser.add_argument_group('training')
        group.add_argument('--nr_epochs', type=int, default=1000, help="total number of epochs to train")
        group.add_argument('--lr', type=float, default=1e-3, help="initial learning rate")
        group.add_argument('--continue', dest='cont',  action='store_true', help="continue training from checkpoint")
        group.add_argument('--ckpt', type=str, default='latest', required=False, help="desired checkpoint to restore")
        group.add_argument('--vis', action='store_true', default=False, help="visualize output in training")
        group.add_argument('--save_frequency', type=int, default=500, help="save models every x epochs")
        group.add_argument('--val_frequency', type=int, default=10, help="run validation every x iterations")
        group.add_argument('--vis_frequency', type=int, default=10, help="visualize output every x iterations")
        group.add_argument('--resample_every', type=int, default=1000000000, help="resample data point")

    def _add_meshing_config_(self, parser):
        '''marching cubes meshing configuration'''
        group = parser.add_argument_group('app')
        group.add_argument('--output-dir', type=str, default='_results/output_mesh',
                           help='Directory to output the mesh after the marching cubes')
        group.add_argument('--resolution', type=int, default=512,
                           help='Resolution for the marching cubes')

import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.BaseSDF import BaseSDF
from models.BaseMLP import BaseMLP

class MlpSDF(BaseSDF):
    def __init__(self, config):
        super().__init__(config)
        
        def siren_sin(x):
            # See DeepSDF supplement Sec. 1.5 for discussion of factor 30
            return torch.sin(30 * x)
        
        if config.activation != 'relu':
            print('using sine')
            # SIREN
            self.decoder = BaseMLP(self.input_dim, self.out_dim, siren_sin, True, self.config)
        else:
            # DeepSDF
            self.decoder = BaseMLP(self.input_dim, self.out_dim, F.relu, True, self.config)

    def sdf(self, x, lod=None):
        return self.decoder(x)


import torch
import torch.nn as nn
import torch.nn.functional as F

def sdf_gradient(y, x, grad_outputs=None):
    if grad_outputs is None:
        grad_outputs = torch.ones_like(y)
    grad = torch.autograd.grad(y, [x], grad_outputs=grad_outputs, create_graph=True)[0]
    return grad


def sdf_loss(pred, gts):
    '''
       pred: prediction
       gts: ground truth
    '''
    gts_sdf = gts['sdf'].cuda()
    gts_normals = gts['normals'].cuda()

    pred_sdf = pred["sdf"]
    pts = pred["coords"]

    gradient = sdf_gradient(pred_sdf, pts)

    # Wherever boundary_values is not equal to zero, we interpret it as a boundary constraint.
    sdf_loss = torch.where(gts_sdf != -1, pred_sdf, torch.zeros_like(pred_sdf))
    inter_loss = torch.where(gts_sdf != -1, torch.zeros_like(pred_sdf), torch.exp(-1e2 * torch.abs(pred_sdf)))
    normal_loss = torch.where(gts_sdf != -1, 1 - F.cosine_similarity(gradient, gts_normals, dim=-1)[..., None],
                                    torch.zeros_like(gradient[..., :1]))
    grad_loss = torch.abs(gradient.norm(dim=-1) - 1)

    # for the coeffients, see https://github.com/vsitzmann/siren/blob/master/loss_functions.py
    return torch.abs(sdf_loss).mean() * 3e3 + inter_loss.mean() * 1e2 + normal_loss.mean() * 1e2 + grad_loss.mean() * 5e1
import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from libs.utils import setparam

class BaseMLP(nn.Module):
    def __init__(self, 
        input_dim, 
        output_dim, 
        activation,
        bias, 
        config     = None,
        num_layers = None, 
        hidden_dim = None
    ):
        super().__init__()

        self.config = config
        self.num_layers = setparam(config, num_layers, 'num_layers')
        self.hidden_dim = setparam(config, hidden_dim, 'hidden_dim')

        self.input_dim = input_dim
        self.output_dim = output_dim        
        self.activation = activation
        self.bias = bias
        
        def sine_init(m):
            with torch.no_grad():
                if hasattr(m, 'weight'):
                    num_input = m.weight.size(-1)
                    # See DeepSDF supplement Sec. 1.5 for discussion of factor 30
                    m.weight.uniform_(-np.sqrt(6 / num_input) / 30, np.sqrt(6 / num_input) / 30)
        
        layers = []
        for i in range(self.num_layers):
            if i == 0: 
                layers.append(nn.Linear(self.input_dim, self.hidden_dim, bias=self.bias))
            else:
                layers.append(nn.Linear(self.hidden_dim, self.hidden_dim, bias=self.bias))
        self.layers = nn.ModuleList(layers)
        
        if config is not None and config.activation != 'relu':
            self.layers.apply(sine_init)
        
        self.lout = nn.Linear(self.hidden_dim, self.output_dim, bias=self.bias)

 
    def forward(self, x):
        for i, l in enumerate(self.layers):
            if i == 0:
                h = self.activation(l(x))
            else:
                h = self.activation(l(h))
        
        out = self.lout(h)
        
        return out
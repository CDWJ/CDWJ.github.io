import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

class BaseSDF(nn.Module):
    def __init__(self, config= None):
        super().__init__()
        self.config = config
        
        self.input_dim = 3
        self.out_dim = 1

    def forward(self, x, lod=None): 
        # allows to take derivative w.r.t. input
        coords = x.clone().detach().requires_grad_(True)
        return {"sdf": self.sdf(coords), "coords": coords}


    def sdf(self, x, lod=None):
        return None

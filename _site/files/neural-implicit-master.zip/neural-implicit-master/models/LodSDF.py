import numpy as np

import torch
import torch.nn as nn
import torch.nn.functional as F

from models.BaseMLP import BaseMLP
from models.BaseSDF import BaseSDF

class BaseLod(BaseSDF):
    def __init__(self, config):
        super().__init__(config)
        self.num_lods = config.num_lods
        self.lod = None

    def forward(self, x, lod=None):
        if lod is None:
            lod = self.lod
        coords = x
        return {"sdf": self.sdf(coords), "coords": coords}

    def sdf(self, x, lod=None):
        if lod is None:
            lod = self.lod
        return None
        
class FeatureVolume(nn.Module):
    def __init__(self, fdim, fsize):
        super().__init__()
        self.fsize = fsize
        self.fdim = fdim
        self.fm = nn.Parameter(torch.randn(1, fdim, fsize+1, fsize+1, fsize+1) * 0.01)

    def forward(self, x):
        N = x.shape[0]
        sample_coords = x.reshape(1, N, 1, 1, 3)
        sample = F.grid_sample(self.fm, sample_coords, align_corners=True, padding_mode='border')[0,:,:,0,0].transpose(0,1)
        
        return sample

class LodSDF(BaseLod):
    def __init__(self, config, init=None):
        super().__init__(config)

        self.fdim = self.config.feature_dim
        self.fsize = self.config.feature_size
        self.hidden_dim = self.config.hidden_dim
        self.sdf_input_dim = self.fdim + self.input_dim
        self.num_decoder = self.config.num_lods 

        # Initialize the feature volumes
        self.features = nn.ModuleList([])
        for i in range(self.config.num_lods):
            self.features.append(FeatureVolume(self.fdim, (2**(i+self.config.base_lod))))

        # Initialize each small MLP
        self.louts = nn.ModuleList([])
        for i in range(self.num_decoder):
            l = nn.Sequential(nn.Linear(self.sdf_input_dim, self.hidden_dim, bias=True),
                            nn.ReLU(),
                            nn.Linear(self.hidden_dim, 1, bias=True),
                            )
            self.louts.append(l)

    def sdf(self, x):
        # SDF query
        l = []
        features = []

        for i in range(self.num_lods):
            
            # Query the features
            feature = self.features[i](x)
            features.append(feature)
            
            # Compute the sum of the queried features
            if i > 0:
                features[i] += features[i-1]
            
            # Concatenate the position in front of the hidden vector
            x_feature = torch.cat([x, features[i]], dim=-1)

            if self.num_decoder == 1:
                decoder_curr = self.louts[0]
            else:
                decoder_curr = self.louts[i]
            
            d = decoder_curr(x_feature)

            # In prediction mode, return the predicted distance 
            if self.lod is not None and self.lod == i:
                return d

            l.append(d)

        if self.training:
            self.loss_preds = l

        return l[-1]
    

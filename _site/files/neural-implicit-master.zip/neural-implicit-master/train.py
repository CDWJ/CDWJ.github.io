from collections import OrderedDict
from tqdm import tqdm
import argparse
from dataset import get_dataloader, resample_epoch
from common import get_config
from utils import cycle
from agent import get_agent
from torch.utils.data import Dataset, DataLoader

def main():
    # create experiment config containing all hyperparameters
    config = get_config('train')

    # create network and training agent
    tr_agent = get_agent(config)

    # load from checkpoint if provided
    if config.cont:
        tr_agent.load_ckpt(config.ckpt)

    # create dataloader
    train_loader, dataset = get_dataloader('train', config)
    val_loader, dataset = get_dataloader('validation', config)
    val_loader = cycle(val_loader)

    # start training
    clock = tr_agent.clock

    for e in range(clock.epoch, config.nr_epochs):
        if e % config.resample_every == 0:
            if not config.dataset_type == 'pointcloud':
                dataset.resample()
                print("Reset DataLoader")
                train_loader = DataLoader(dataset, batch_size=config.batch_size, 
                                                        shuffle=True, pin_memory=True, num_workers=0)
                print('create_dataloader')
            # train_loader = resample_epoch(e, dataset, config, 'train')
            # val_loader = resample_epoch(e, dataset, config, 'validation')
            # val_loader = cycle(val_loader)
        # begin iteration
        pbar = tqdm(train_loader)
        for b, data in enumerate(pbar):
            # train step
            outputs, losses = tr_agent.train_func(data)

            # visualize
            if config.vis and clock.step % config.vis_frequency == 0:
                tr_agent.visualize_batch(data, "train", outputs=outputs)

            pbar.set_description("EPOCH[{}][{}]".format(e, b))
            pbar.set_postfix(OrderedDict({k: v.item() for k, v in losses.items()}))

            # validation step
            if clock.step % config.val_frequency == 0:
                data = next(val_loader)
                outputs, losses = tr_agent.val_func(data)

                if config.vis and clock.step % config.vis_frequency == 0:
                    tr_agent.visualize_batch(data, "validation", outputs=outputs)

            clock.tick()

        tr_agent.update_learning_rate()
        clock.tock()

        if clock.epoch % config.save_frequency == 0:
            tr_agent.save_ckpt()
        tr_agent.save_ckpt('latest')

if __name__ == '__main__':
    main()

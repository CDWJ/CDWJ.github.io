# Neural Signed Distance Function for Shape Representation

### Set up the environment
You can then set up a conda environment with all dependencies like so:
```
conda env create -f environment.yml
conda activate neurimp
```

### Run the experiments
First, change the `proj-dir` in line 82 of `common.py` to be your project directory. (You don't want to pass it in the command line every time. )

Run the code with DeepSDF:
```
python train.py --net MlpSDF --data_path data/spot.xyz --num-layers 5 --nr_epochs 1000 --batch_size=2500 --exp_name deepsdf_spot
```
Run the code with SIREN:
```
python train.py --data_path data/spot.xyz --net MlpSDF --activation sine --num-layers 3 --nr_epochs 1000 --batch_size=2500 --hidden-dim 256 --lr 5e-4 --exp_name siren_spot
```
Run the code with NGLoD:
```
python train.py --data_path data/spot.obj --dataset_type mesh --net LodSDF --num-lods 5 --nr_epochs 1000 --batch_size=20000 --exp_name nglod_spot
```


### Generate the mesh using marching cubes
To generate the mesh using marching cubes:

For DeepSDF:
```
python test/test_sdf.py --net MlpSDF --num-layers 5 --pretrained deepsdf_spot/model/latest_model.pth
```

For SIREN:
```
python test/test_sdf.py --net MlpSDF --activation sine --num-layers 3 --hidden-dim 256  --pretrained siren_spot/model/latest_model.pth
```

For NGLoD:
```
python test/test_sdf.py  --dataset_type mesh --net LodSDF --num-lods 5 --pretrained nglod_spot/model/latest_model.pth 
```

The parameters (e.g., `--num-layers 5`) here need to match the trainning setting. The generated result will be in `_results/output_mesh/` folder.

## Project Structure
The project structure is as follows:

- __common.py__  
  Define hyperparameters and expriment configuration, which can later be changed by specifying command-line arguments. This config will be used by other modules. Default value for some args like `data_root`, `proj_dir` must be specified.
- __dataset.py__  
  Define customized dataset/dataloader.
- __network.py__  
  Define customized network architecture.
- __agent.py__  
  A base trainer is defined for the control of training process, e.g. forward, backward, loss recording, checkpoint saving/loading. A customized trainer should be inherited from the base trainer to implement customized functionality, e.g. `forward` at least.
- __train.py__  
  The main file to start training. Normally no need to change. 
- __utils.py__  
  Define some useful functions/classes. Normally no need to change.

See all arguments by
```
python train.py -h
```

Once training is started, experiment configuration, training logs(open by tensorboard) and checkpoint models will be saved at `{exp_dir}`, which is soft-linked by `train_log` under current folder.

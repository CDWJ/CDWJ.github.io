import sdf_meshing

import sys
sys.path.append('.')
sys.path.append('..')
from common import get_config
from networks import get_network

import torch
import os


class SDFDecoder(torch.nn.Module):
	def __init__(self):
		super().__init__()
		# Define the model.
		# Pick device
		use_cuda = torch.cuda.is_available()
		device = torch.device('cuda' if use_cuda else 'cpu')

		# load the pretrained network
		self.net = get_network(config)
		self.net.load_state_dict(torch.load(config.pretrained))

		self.net.to(device)
		self.net.eval()
		print("Total number of parameters: {}".format(sum(p.numel() for p in self.net.parameters())))

	def forward(self, pts):
		return self.net.sdf(pts)

if __name__ == '__main__':

	config = get_config('test')

	# Get model name
	if config.pretrained is not None:
		name = config.pretrained.split('/')[-1].split('.')[0]
	else:
		assert False and "No network weights specified!"

	sdf_decoder = SDFDecoder()

	sdf_meshing.create_mesh(sdf_decoder, os.path.join(config.output_dir, config.exp_name), N=config.resolution)

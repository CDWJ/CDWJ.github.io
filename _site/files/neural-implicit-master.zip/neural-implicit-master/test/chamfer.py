import torch
import sdf_meshing
import mesh_to_sdf

import trimesh
import pyrender
import os

import sys
sys.path.append('.')
sys.path.append('..')
from common import get_config
from networks import get_network
from libs.torchgp import load_obj, point_sample, sample_surface, normalize
import os
os.environ['PYOPENGL_PLATFORM'] = 'egl'

import torch

import numpy as np
from sklearn.neighbors import NearestNeighbors


def chamfer_distance(x, y, metric='l1', direction='bi'):
    
    if direction=='y_to_x':
        x_nn = NearestNeighbors(n_neighbors=1, leaf_size=1, algorithm='kd_tree', metric=metric).fit(x)
        min_y_to_x = x_nn.kneighbors(y)[0]
        chamfer_dist = np.mean(min_y_to_x)
    elif direction=='x_to_y':
        y_nn = NearestNeighbors(n_neighbors=1, leaf_size=1, algorithm='kd_tree', metric=metric).fit(y)
        min_x_to_y = y_nn.kneighbors(x)[0]
        chamfer_dist = np.mean(min_x_to_y)
    elif direction=='bi':
        x_nn = NearestNeighbors(n_neighbors=1, leaf_size=1, algorithm='kd_tree', metric=metric).fit(x)
        min_y_to_x = x_nn.kneighbors(y)[0]
        y_nn = NearestNeighbors(n_neighbors=1, leaf_size=1, algorithm='kd_tree', metric=metric).fit(y)
        min_x_to_y = y_nn.kneighbors(x)[0]
        chamfer_dist = np.mean(min_y_to_x) + np.mean(min_x_to_y)
    else:
        raise ValueError("Invalid direction type. Supported types: \'y_x\', \'x_y\', \'bi\'")
        
    return chamfer_dist

class SDFDecoder(torch.nn.Module):
    def __init__(self):
        super().__init__()
        # Define the model.
        # Pick device
        use_cuda = torch.cuda.is_available()
        device = torch.device('cuda' if use_cuda else 'cpu')

        #load the pretrained network
        self.net = get_network(config)
        self.net.load_state_dict(torch.load(config.pretrained))

        self.net.to(device)
        self.net.eval()
        print("Total number of parameters: {}".format(sum(p.numel() for p in self.net.parameters())))

    def forward(self, pts):
        return self.net.sdf(pts)

if __name__ == '__main__':

    config = get_config('test')

    # Get model name
    if config.pretrained is not None:
        name = config.pretrained.split('/')[-1].split('.')[0]
    else:
        assert False and "No network weights specified!"

    # sdf_decoder = SDFDecoder()
    V, F = load_obj(config.data_path)
    V, F = normalize(V, F)
    mesh = trimesh.Trimesh(vertices=V.numpy(),
                       faces=F.numpy())
    pred_mesh = trimesh.load(config.mesh_path) 
    Vpred, Fpred = normalize(torch.from_numpy(pred_mesh.vertices), torch.from_numpy(pred_mesh.faces))

    print(f'chamfer for {config.exp_name} : {chamfer_distance(V.numpy(), Vpred.numpy())}')
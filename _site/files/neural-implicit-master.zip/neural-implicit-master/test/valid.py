import torch
import sdf_meshing
import mesh_to_sdf

import trimesh
import pyrender
import os

import sys
sys.path.append('.')
sys.path.append('..')
from common import get_config
from networks import get_network
from libs.torchgp import load_obj, point_sample, sample_surface, normalize
import os
os.environ['PYOPENGL_PLATFORM'] = 'egl'

import torch

import numpy as np
from sklearn.neighbors import NearestNeighbors


def compute_iou(dist_gt, dist_pr):
    """Intersection over Union.
    
    Args:
        dist_gt (torch.Tensor): Groundtruth signed distances
        dist_pr (torch.Tensor): Predicted signed distances
    """

    occ_gt = (dist_gt < 0).byte()
    occ_pr = (dist_pr < 0).byte()

    area_union = torch.sum((occ_gt | occ_pr).float())
    area_intersect = torch.sum((occ_gt & occ_pr).float())

    iou = area_intersect / area_union
    return 100. * iou


class SDFDecoder(torch.nn.Module):
    def __init__(self):
        super().__init__()
        # Define the model.
        # Pick device
        use_cuda = torch.cuda.is_available()
        device = torch.device('cuda' if use_cuda else 'cpu')

        #load the pretrained network
        self.net = get_network(config)
        self.net.load_state_dict(torch.load(config.pretrained))

        self.net.to(device)
        self.net.eval()
        print("Total number of parameters: {}".format(sum(p.numel() for p in self.net.parameters())))

    def forward(self, pts):
        return self.net.sdf(pts)

if __name__ == '__main__':

    config = get_config('test')

    # Get model name
    if config.pretrained is not None:
        name = config.pretrained.split('/')[-1].split('.')[0]
    else:
        assert False and "No network weights specified!"

    sdf_decoder = SDFDecoder()
    V, F = load_obj(config.data_path)
    V, F = normalize(V, F)
    N = 50
    mesh = trimesh.Trimesh(vertices=V.numpy(),
                       faces=F.numpy())
    # pts = point_sample(V, F, config.sample_mode, config.num_samples)
    voxel_origin = [-1, -1, -1]
    voxel_size = 2.0 / (N - 1)

    overall_index = torch.arange(0, N ** 3, 1, out=torch.LongTensor())
    pts = torch.zeros(N ** 3, 3)

    # transform first 3 columns
    # to be the x, y, z index
    pts[:, 2] = overall_index % N
    pts[:, 1] = (overall_index.long() / N) % N
    pts[:, 0] = ((overall_index.long() / N) / N) % N

    # transform first 3 columns
    # to be the x, y, z coordinate
    pts[:, 0] = (pts[:, 0] * voxel_size) + voxel_origin[2]
    pts[:, 1] = (pts[:, 1] * voxel_size) + voxel_origin[1]
    pts[:, 2] = (pts[:, 2] * voxel_size) + voxel_origin[0]

    model_sdf = sdf_meshing.compute_sdf(sdf_decoder, pts, config.num_samples)
    d = mesh_to_sdf.mesh_to_sdf(mesh, pts.numpy(), surface_point_method='scan', sign_method='normal', bounding_radius=None, scan_count=100, scan_resolution=400, sample_point_count=config.num_samples, normal_sample_count=11)

    d = d[...,None]
    d = torch.from_numpy(d).cpu()
    print(f'iou for {config.exp_name} : {compute_iou(d, model_sdf)}')
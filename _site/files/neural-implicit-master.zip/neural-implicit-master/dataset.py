from torch.utils.data import Dataset, DataLoader
import numpy as np
import torch

from common import get_config
from agent import get_agent

import pandas as pd
from pyntcloud import PyntCloud
from libs.torchgp import load_obj, point_sample, sample_surface, normalize
import mesh_to_sdf

import trimesh
import pyrender
import os
os.environ['PYOPENGL_PLATFORM'] = 'egl'

def get_dataloader(phase, config):
    is_shuffle = phase == 'train'
    dataset = None
    if config.dataset_type == 'pointcloud':
        dataset = PointCloudDataset(phase, config)
    else:
        dataset = MeshDataset(phase, config)
    dataloader = DataLoader(dataset, batch_size=config.batch_size, shuffle=is_shuffle, num_workers=config.num_workers,
                            worker_init_fn=np.random.seed())
    return dataloader, dataset


def resample_epoch(epoch, dataset, config, phase):
    is_shuffle = phase == 'train'
    if not config.dataset_type == 'pointcloud':
        dataset.resample()
        print("Reset DataLoader")
        dataloader = DataLoader(dataset, batch_size=config.batch_size, 
                                                shuffle=is_shuffle, pin_memory=True, num_workers=0)
        print('create_dataloader')
    return dataloader


class PointCloudDataset(Dataset):
    def __init__(self, phase, config):
        super().__init__()

        self.aug = phase == "train"

        print("Loading point cloud")
        point_cloud = np.genfromtxt(config.data_path)
        print("Finished loading point cloud")

        coords = point_cloud[:, :3]
        self.normals = point_cloud[:, 3:]

        # Reshape point cloud such that it lies in bounding box of (-1, 1) (distorts geometry, but makes for high
        # sample efficiency)
        coords -= np.mean(coords, axis=0, keepdims=True)
        coord_max = np.amax(coords)
        coord_min = np.amin(coords)

        self.coords = (coords - coord_min) / (coord_max - coord_min)
        self.coords -= 0.5
        self.coords *= 2.

        self.on_surface_points = config.on_surface_points

    def __len__(self):
        return self.coords.shape[0] // self.on_surface_points + 1

    def __getitem__(self, idx):
        point_cloud_size = self.coords.shape[0]

        off_surface_samples = self.on_surface_points  # **2
        total_samples = self.on_surface_points + off_surface_samples

        # Random coords
        rand_idcs = np.random.choice(point_cloud_size, size=self.on_surface_points)

        on_surface_coords = self.coords[rand_idcs, :]
        on_surface_normals = self.normals[rand_idcs, :]

        off_surface_coords = np.random.uniform(-1, 1, size=(off_surface_samples, 3))
        off_surface_normals = np.ones((off_surface_samples, 3)) * -1

        sdf = np.zeros((total_samples, 1))  # on-surface = 0
        sdf[self.on_surface_points:, :] = -1  # off-surface = -1

        coords = np.concatenate((on_surface_coords, off_surface_coords), axis=0)
        normals = np.concatenate((on_surface_normals, off_surface_normals), axis=0)

        return {'coords': torch.from_numpy(coords).float(), 
                'sdf': torch.from_numpy(sdf).float(),
                'normals': torch.from_numpy(normals).float()}
    
    
    
class MeshDataset(Dataset):
    def __init__(self, phase, config):
        super().__init__()

        self.aug = phase == "train"
        
        self.sample_mode = config.sample_mode
        self.num_samples = config.num_samples
        self.V, self.F = load_obj(config.data_path)
        self.V, self.F = normalize(self.V, self.F)
        self.trimesh = trimesh.Trimesh(vertices=self.V.numpy(),
                       faces=self.F.numpy())
        self.resample()
        
    def resample(self):
        """Resample SDF samples."""
        
        self.nrm = None
        self.pts = point_sample(self.V, self.F, self.sample_mode, self.num_samples)
        # self.d = mesh_to_sdf.mesh_to_sdf(self.trimesh, self.pts.numpy(), surface_point_method='scan', sign_method='normal', bounding_radius=1, scan_count=200, scan_resolution=512, sample_point_count=self.num_samples, normal_sample_count=11)
        self.d = mesh_to_sdf.mesh_to_sdf(self.trimesh, self.pts.numpy(), surface_point_method='scan', sign_method='normal', bounding_radius=None, scan_count=100, scan_resolution=400, sample_point_count=self.num_samples, normal_sample_count=11)

        self.d = self.d[...,None]
        self.d = torch.from_numpy(self.d).cpu()
        self.pts = self.pts.cpu()


    def __getitem__(self, idx: int):
        """Retrieve point sample."""
        return {'coords': self.pts[idx].float(), 
                'sdf': self.d[idx].float(),
                'normals': self.pts[idx].float()}
            
    def __len__(self):
        """Return length of dataset (number of _samples_)."""

        return self.d.size()[0]

    def num_shapes(self):
        """Return length of dataset (number of _mesh models_)."""

        return 1



def test():
    config = get_config('eval')
    # create network and training agent
    dataset = PointCloudDataset('eval', config)
    data = dataset.__getitem__(0)
    points = data['coords'].numpy()
    sdf = data['sdf'].numpy()
    colors = np.zeros(points.shape)
    print(colors.shape)
    colors[:dataset.on_surface_points, :] = [1, 0, 0]
    colors[dataset.on_surface_points:, :] = [0, 0, 1]
    cloud = PyntCloud(pd.DataFrame(
                        data=np.hstack((points, colors)),
                        columns=["x", "y", "z", "red", "green", "blue"]))
    cloud.to_file("output.ply")

if __name__ == "__main__":
    test()

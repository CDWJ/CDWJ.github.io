import torch
import torch.nn as nn
import random

import numpy as np
import torch.nn.functional as F

from models.MlpSDF import MlpSDF
from models.LodSDF import LodSDF

def get_network(config):
    if config.net == 'LodSDF':
        return LodSDF(config)
    else:
        return MlpSDF(config)


def test():
    pass


if __name__ == '__main__':
    test()

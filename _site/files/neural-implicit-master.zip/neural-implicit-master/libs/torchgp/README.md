# torchgp

This is a small library for handling mesh data with textures and materials.

### Dependencies

* PyTorch
* numpy
* [tinyobjloader](https://github.com/tinyobjloader/tinyobjloader)

